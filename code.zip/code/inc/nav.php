<nav>
<ul>
<li><a href="code/index.php">Home</a></li>
<li><a href="inc/nav.php/insert.php">Add Hero</a></li>
<li><a href="inc/nav.php/update.php">Real Name</a></li>
<li><a href="inc/nav.php/delete.php">Delete</a></li>
</ul>
</nav>